<?php $__env->startSection('breadcrumb'); ?>
    <li class="inline-flex items-center">
        <span class="mx-2 text-gray-500">/</span>
        <span class="text-gray-700">Portofolio</span>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-8 bg-white rounded-lg shadow-md">
        <div class="flex justify-between items-center mb-8">
            <h2 class="text-2xl font-extrabold text-center tracking-tight">Daftar Portfolio</h2>
            <a href="<?php echo e(route('admin.portfolio.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white hover:text-gray-100 font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300">Tambah Portfolio</a>
        </div>

        <?php echo $__env->make('components.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if($portfolios->isEmpty()): ?>
            <p class="text-center text-gray-500 py-6">Data tidak ada</p>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="w-full border border-gray-200 rounded-lg border-separate border-spacing-0">
                    <thead class="bg-gray-200 text-gray-700 border-b border-gray-200">
                        <tr>
                            <th class="px-2 py-4 w-[10px] border border-gray-300 rounded-tl-lg">No</th>
                            <th class="px-2 py-4 w-[20%] border border-gray-300">Gambar</th>
                            <th class="px-2 py-4 w-[50%] border border-gray-300">Nama Proyek</th>
                            <th class="px-2 py-4 w-[20%] border border-gray-300 hidden md:table-cell">Deskripsi</th>
                            <th class="px-2 py-4 w-[10%] border border-gray-300 rounded-tr-lg">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="<?php echo e($index % 2 === 0 ? 'bg-gray-100' : 'bg-white'); ?> hover:bg-gray-200 border-t border-gray-300">
                                <td class="text-center border border-gray-300"><?php echo e($portfolios->firstItem() + $index); ?></td>
                                <td class="border border-gray-300">
                                    <?php if($portfolio->image_1): ?>
                                        <img src="<?php echo e(asset($portfolio->image_1)); ?>" alt="<?php echo e($portfolio->image_1); ?>" class="w-full" loading="lazy">
                                    <?php else: ?>
                                        Tidak ada gambar
                                    <?php endif; ?>
                                </td>
                                <td class="border border-gray-300 p-4"><?php echo e($portfolio->project_name ? $portfolio->project_name->translated_text : '-'); ?></td>
                                <td class="border border-gray-300 p-4 hidden md:table-cell"><?php echo e($portfolio->project_desc ? $portfolio->project_desc->translated_text : '-'); ?></td>
                                <td class="border border-gray-300 p-4">
                                    <div class="flex flex-col gap-2">
                                        <a href="<?php echo e(route('admin.portfolio.show', $portfolio->id)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300">
                                            <i class="fas fa-eye"></i> Lihat
                                        </a>

                                        <a href="<?php echo e(route('admin.portfolio.edit', $portfolio->id)); ?>" class="bg-yellow-500 hover:bg-yellow-700 text-white text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>

                                        <form id="delete-form-<?php echo e($portfolio->id); ?>" action="<?php echo e(route('admin.portfolio.destroy', $portfolio->id)); ?>" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo e(method_field('DELETE')); ?>

                                            <button type="button" class="w-full bg-red-500 hover:bg-red-700 text-white text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300" onclick="confirmDelete(<?php echo e($portfolio->id); ?>)">
                                                <i class="fas fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo $__env->make('components.pagination', ['paginator' => $portfolios], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
