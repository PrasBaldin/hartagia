<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.pageBanner', ['current' => __('menu.contact')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section>
        <div class="container">
            <div class="flex items-center justify-between flex-col md:flex-row gap-10 py-20">
                <!-- Contact Form -->
                <div class="mb-6 md:mb-0 max-w-full w-[400px]">
                    <form class="bg-white rounded-lg shadow-md p-10 space-y-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 200;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-right", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                        <h3 class="uppercase tracking-widest text-green-700 mb-10">
                            <?php echo e(__('contact.form.title')); ?>

                        </h3>
                        <div class="flex items-center mb-4">
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full mr-3">
                                <i class="fas fa-user"></i>
                            </span>
                            <label for="name" class="block text-gray-700 font-semibold">
                                <?php echo e(__('contact.form.name')); ?>

                            </label>
                        </div>
                        <input type="text" id="name" name="name" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-700" required>

                        <div class="flex items-center mb-4">
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full mr-3">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <label for="email" class="block text-gray-700 font-semibold">
                                <?php echo e(__('contact.form.email')); ?>

                            </label>
                        </div>
                        <input type="email" id="email" name="email" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-700" required>

                        <div class="flex items-center mb-4">
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full mr-3">
                                <i class="fas fa-comment-dots"></i>
                            </span>
                            <label for="message" class="block text-gray-700 font-semibold">
                                <?php echo e(__('contact.form.message')); ?>

                            </label>
                        </div>
                        <textarea id="message" name="message" rows="4" class="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-700" required></textarea>

                        <button type="submit" class="w-full bg-gradient-to-r from-green-700 to-green-500 text-white font-semibold py-2 rounded hover:from-green-800 hover:to-green-600 transition flex items-center justify-center gap-2">
                            <i class="fas fa-paper-plane"></i>
                            <?php echo e(__('contact.form.send')); ?>

                        </button>
                    </form>
                </div>
                <!-- Contact Info -->
                <div class="md:w-1/2">
                    <div class="mb-6">
                        <h2 class="uppercase tracking-widest text-green-700 mb-2" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 200;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-down", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <?php echo e(__('contact.title')); ?>

                        </h2>
                        <h2 class="text-2xl md:text-4xl font-semibold mb-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 300;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <?php echo e(__('contact.subtitle')); ?>

                        </h2>
                    </div>
                    <div id="contactInfo" class="space-y-6">
                        <div class="flex items-center space-x-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 400;
                $anchorAttr = " data-aos-anchor=\"#contactInfo\"";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full">
                                <i class="fas fa-envelope"></i>
                            </span>
                            <span class="text-lg">
                                <?php echo e($contact->contact_email ? $contact->contact_email : '-'); ?>

                            </span>
                        </div>
                        <div class="flex items-center space-x-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 500;
                $anchorAttr = " data-aos-anchor=\"#contactInfo\"";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full">
                                <i class="fas fa-phone-alt"></i>
                            </span>
                            <span class="text-lg">
                                <?php echo e($contact->contact_phone ? $contact->contact_phone : '-'); ?>

                            </span>
                        </div>
                        <div class="flex items-center space-x-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 600;
                $anchorAttr = " data-aos-anchor=\"#contactInfo\"";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full mt-1 flex-shrink-0">
                                <i class="fab fa-whatsapp text-2xl"></i>
                            </span>
                            <span class="text-lg break-words max-w-xs">
                                <?php echo e($contact->contact_wa ? $contact->contact_wa : '-'); ?>

                            </span>
                        </div>
                        <div class="flex items-center space-x-4" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 700;
                $anchorAttr = " data-aos-anchor=\"#contactInfo\"";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <span class="inline-flex items-center justify-center w-10 h-10 bg-green-700 text-white rounded-full mt-1 flex-shrink-0">
                                <i class="fas fa-map-marker-alt"></i>
                            </span>
                            <span class="text-lg break-words max-w-xs">
                                <?php echo e($contact->office_address ? $contact->office_address : '-'); ?>

                            </span>
                        </div>
                    </div>
                    <div class="mt-10" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 700;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d247.8785495995965!2d106.86572126454624!3d-6.256248850923886!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f3004ab058a9%3A0xa31cc96a8bde57e5!2sPT.%20HARTA%20GEMILANG%20ASELINDO!5e0!3m2!1sen!2sid!4v1751869112603!5m2!1sen!2sid" width="100%" height="200" style="border:0; border-radius: 1rem;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
