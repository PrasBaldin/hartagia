<?php $__env->startSection('breadcrumb'); ?>
    <li class="inline-flex items-center">
        <span class="mx-2 text-gray-500">/</span>
        <span class="text-gray-700">Pengaturan</span>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-8 mt-6 bg-white rounded-lg shadow-md space-y-8">

        <!-- General Website Information -->
        <div x-data="{ open: true }" class="border rounded mb-4">
            <button type="button" @click="open = !open" class="w-full flex justify-between items-center px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-t focus:outline-none">
                <span class="text-lg font-semibold">Informasi Umum Website</span>
                <svg :class="{ 'transform rotate-180': open }" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div x-show="open" class="px-6 py-4" x-transition>
                <form method="POST" action="<?php echo e(route('setting.update')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Nama Situs</label>
                        <input type="text" name="site_name" class="w-full border rounded px-3 py-2" value="<?php echo e($setting->site_name); ?>">
                    </div>

                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Deskripsi Singkat</label>
                        <textarea name="site_description" class="w-full border rounded px-3 py-2" rows="2"><?php echo e($setting->site_description); ?></textarea>
                    </div>

                    <div class="mb-4 flex items-center space-x-6">
                        <div>
                            <label class="block mb-1 font-medium">Logo</label>
                            <input type="file" name="logo">
                            <?php if($setting->logo): ?>
                                <img src="<?php echo e(asset($setting->logo)); ?>" class="mt-2 w-24">
                            <?php endif; ?>
                        </div>
                        <div>
                            <label class="block mb-1 font-medium">Favicon</label>
                            <input type="file" name="favicon">
                            <?php if($setting->favicon): ?>
                                <img src="<?php echo e(asset($setting->favicon)); ?>" class="mt-2 w-8">
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Contact & Social Media -->
        <div x-data="{ open: false }" class="border rounded mb-4">
            <button type="button" @click="open = !open" class="w-full flex justify-between items-center px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-t focus:outline-none">
                <span class="text-lg font-semibold">Kontak & Media Sosial</span>
                <svg :class="{ 'transform rotate-180': open }" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div x-show="open" class="px-6 py-4" x-transition>
                <form method="POST" action="<?php echo e(route('setting.update.contact')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Email Kontak</label>
                        <input type="email" class="w-full border rounded px-3 py-2" placeholder="Email Kontak">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Alamat Kantor</label>
                        <input type="text" class="w-full border rounded px-3 py-2" placeholder="Alamat Kantor">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Facebook</label>
                        <input type="url" class="w-full border rounded px-3 py-2" placeholder="Link Facebook">
                    </div>
                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Instagram</label>
                        <input type="url" class="w-full border rounded px-3 py-2" placeholder="Link Instagram">
                    </div>
                    <!-- Add more social media as needed -->
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Simpan</button>
                </form>
            </div>
        </div>

        <!-- Admin Settings -->
        <div x-data="{ open: false }" class="border rounded mb-4">
            <button type="button" @click="open = !open" class="w-full flex justify-between items-center px-4 py-3 bg-gray-100 hover:bg-gray-200 rounded-t focus:outline-none">
                <span class="text-lg font-semibold">Pengaturan Admin</span>
                <svg :class="{ 'transform rotate-180': open }" class="w-5 h-5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                </svg>
            </button>
            <div x-show="open" class="px-6 py-4" x-transition>
                <form>
                    <div class="mb-4">
                        <label class="block mb-1 font-medium">Ganti Password</label>
                        <input type="password" class="w-full border rounded px-3 py-2" placeholder="Password Baru">
                    </div>
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Simpan</button>
                </form>
            </div>
        </div>

        <!-- Alpine.js CDN (add this before </body> if not already included) -->
        <?php $__env->startPush('scripts'); ?>
            <script src="//unpkg.com/alpinejs" defer></script>
        <?php $__env->stopPush(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
