<?php if($paginator->hasPages()): ?>
    <nav class="flex justify-center mt-10" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 200;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
        
        <ul class="inline-flex items-center space-x-1 text-sm">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="px-3 py-2 text-gray-400 bg-gray-100 rounded">
                    <i class="fas fa-angle-left"></i>
                </li>
            <?php else: ?>
                <li>
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-3 py-2 bg-white border rounded hover:bg-gray-100">
                        <i class="fas fa-angle-left"></i>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <li class="px-3 py-2 font-bold text-white bg-green-500 rounded">
                        <?php echo e($page); ?>

                    </li>
                <?php else: ?>
                    <li>
                        <a href="<?php echo e($url); ?>" class="px-3 py-2 bg-white border rounded hover:bg-gray-100">
                            <?php echo e($page); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-3 py-2 bg-white border rounded hover:bg-gray-100">
                        <i class="fas fa-angle-right"></i>
                    </a>
                </li>
            <?php else: ?>
                <li class="px-3 py-2 text-gray-400 bg-gray-100 rounded">
                    <i class="fas fa-angle-right"></i>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
