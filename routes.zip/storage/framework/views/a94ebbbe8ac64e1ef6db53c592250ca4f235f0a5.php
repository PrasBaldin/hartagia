<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.pageBanner', ['current' => __('menu.portfolio')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section>
        <div class="container mx-auto py-12 pb-20">
            <h1 class="py-20 md:w-3/4 text-4xl lg:text-6xl pr-20 font-bold leading-tight" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : 200;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-down", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                <?php echo e(__('portfolio.headline')); ?>

            </h1>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $caption = $portfolio->project_name ? $portfolio->project_name->translated_text : null;
                        $delay = 200 + $index * 100; // Delay bertambah 100ms untuk setiap portfolio
                        $anchor = '#portfolio' . $index; // Anchor untuk AOS
                     ?>
                    <div id="portfolio<?php echo e($index); ?>" class="group relative overflow-hidden rounded-xl shadow-lg cursor-pointer" <?php
                $ua = request()->header("User-Agent");
                $delayFinal = (preg_match("/Mobile|Android|iPhone/", $ua)) ? 200 : $delay;
                $anchorAttr = "";
                $offsetAttr = "";
                printf("data-aos=\"%s\" data-aos-delay=\"%d\"%s%s", "fade-up", $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                        <a href="<?php echo e(route('portfolio.show', ['lang' => app()->getLocale(), 'slug' => $portfolio->slug])); ?>" class="block">
                            <img src="<?php echo e(asset($portfolio->image_1)); ?>" alt="<?php echo e($caption); ?>" class="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110 group-hover:brightness-75">

                            <!-- Hover overlay on desktop -->
                            <div class="absolute inset-0 hidden md:flex p-4 items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40">
                                <span class="text-white text-xl font-semibold tracking-wide">
                                    <?php echo e($caption); ?>

                                </span>
                            </div>

                            <!-- Project name for mobile view -->
                            <div class="md:hidden absolute bottom-2 right-3 bg-black/60 px-2 py-1 rounded text-white text-sm font-medium">
                                <?php echo e($caption); ?>

                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('components.pagination', ['paginator' => $portfolios], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
