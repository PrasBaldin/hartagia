<?php $__env->startSection('breadcrumb'); ?>
    <li class="inline-flex items-center">
        <span class="mx-2 text-gray-500">/</span>
        <a href="<?php echo e(route('admin.portfolio.index')); ?>" class="text-gray-500 hover:text-gray-700 transition">Portofolio</a>
        <span class="mx-2 text-gray-500">/</span>
        <span class="text-gray-700">Tambah Portofolio</span>
    </li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex flex-col justify-center items-center">
        <div class="w-full bg-white backdrop-blur-md rounded-lg shadow-lg border px-4 py-8 relative overflow-hidden">
            <h2 class="text-2xl font-extrabold mb-10 text-center tracking-tight">Tambah Portfolio</h2>

            <?php echo $__env->make('components.alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <form action="<?php echo e(route('admin.portfolio.store')); ?>" method="POST" enctype="multipart/form-data" class="grid grid-cols-2 gap-6 p-6">
                <?php echo e(csrf_field()); ?>

                <!-- Kolom Bahasa Indonesia -->
                <div>
                    <label for="project_name_id" class="block mb-2 text-base font-semibold">Judul (Indonesia)</label>
                    <input type="text" name="project_name_id" id="project_name_id" class="w-full px-4 py-3 border rounded-lg focus:ring-green-400">

                    <label for="project_desc_id" class="block mt-4 mb-2 text-base font-semibold">Deskripsi (Indonesia)</label>
                    <textarea name="project_desc_id" id="project_desc_id" class="w-full px-4 py-3 border rounded-lg focus:ring-green-400 resize-none"></textarea>
                </div>

                <!-- Kolom Bahasa Inggris -->
                <div>
                    <label for="project_name_en" class="block mb-2 text-base font-semibold">Title (English)</label>
                    <input type="text" name="project_name_en" id="project_name_en" class="w-full px-4 py-3 border rounded-lg focus:ring-green-400">

                    <label for="project_desc_en" class="block mt-4 mb-2 text-base font-semibold">Description (English)</label>
                    <textarea name="project_desc_en" id="project_desc_en" class="w-full px-4 py-3 border rounded-lg focus:ring-green-400 resize-none"></textarea>
                </div>

                <!-- Input Gambar -->
                <div class="col-span-2 grid grid-cols-1 gap-4">
                    <!-- Gambar Utama -->
                    <div class="mb-4">
                        <label for="image_1" class="block mb-2 font-semibold">Gambar Utama</label>
                        <input type="file" name="image_1" id="image_1" class="w-full border rounded-lg p-3" required>
                    </div>

                    <!-- Gambar Tambahan (opsional, bisa pilih banyak) -->
                    <div>
                        <label for="image_extra[]" class="block mb-2 font-semibold">Gambar Tambahan (Optional, maksimal 4 gambar)</label>
                        <input type="file" name="image_extra[]" id="image_extra" class="w-full border rounded-lg p-3" multiple>
                    </div>
                </div>

                <!-- Tombol Submit -->
                <div class="col-span-2 text-center">
                    <button type="submit" class="bg-green-600 text-white px-6 py-3 rounded-lg font-bold hover:bg-green-700 transition">
                        Simpan
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
