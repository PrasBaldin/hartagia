<?php if(session('success')): ?>
    <div class="my-8 p-4 bg-green-100 border-l-4 border-green-500 text-green-700 rounded-xl shadow">
        <strong>Berhasil!</strong> <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('warning')): ?>
    <div class="my-8 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 rounded-xl shadow">
        <strong>Peringatan!</strong> <?php echo e(session('warning')); ?>

    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="my-8 p-4 bg-red-100 border-l-4 border-red-500 text-red-700 rounded-xl shadow">
        <strong>Kesalahan!</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
