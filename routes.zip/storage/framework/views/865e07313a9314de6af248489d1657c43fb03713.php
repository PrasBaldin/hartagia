<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.pageBanner', ['current' => __('menu.portfolio')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section>
        <div class="container mx-auto py-12 pb-20">
            <h1 class="py-20 md:w-3/4 text-4xl lg:text-6xl pr-20 font-bold leading-tight"><?php echo e(__('portfolio.headline')); ?></h1>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden transition-shadow duration-300 hover:shadow-2xl group">
                        <a href="#">
                            <img src="<?php echo e(asset('storage/' . $portfolio->image_1)); ?>" alt="<?php echo e($portfolio->project_name ? $portfolio->project_name->translated_text : 'value'); ?>" class="w-full h-[200px] object-cover transition-transform duration-300 group-hover:scale-110">
                        </a>
                        <div class="p-6">
                            <h3 class="text-xl font-semibold mb-2 text-gray-900"><?php echo e($portfolio->project_name ? $portfolio->project_name->translated_text : 'value'); ?></h3>
                            <p class="text-gray-700 mb-4"><?php echo e($portfolio->project_desc ? $portfolio->project_name->translated_text : 'value'); ?></p>
                            <a href="#" class="btn button-primary mt-6">
                                <?php echo e(__('portfolio.view_details')); ?>

                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo $__env->make('components.pagination', ['paginator' => $portfolios], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
