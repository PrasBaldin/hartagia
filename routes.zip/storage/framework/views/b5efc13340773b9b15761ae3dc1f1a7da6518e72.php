<?php $__env->startSection('content'); ?>
    <div class="lg:max-w-4xl mx-auto px-4 py-6">

        
        <div class="w-full lg:max-w-4xl mb-4 text-center">
            <h1 class="text-5xl font-bold mb-2">Dashboard</h1>
            <p class="text-xl text-gray-500 mb-10">Selamat datang di halaman admin.</p>
        </div>

        
        <div class="w-full lg:max-w-4xl mb-4">
            <p class="text-lg text-gray-600 mb-4 text-center">Total Pengunjung Seluruh Waktu: <span class="font-bold text-green-600"><?php echo e($totalVisitorCount); ?></span></p>
            <div class="flex flex-col md:flex-row gap-6 justify-between">
                <div class="flex-1 bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-semibold">Pengunjung Hari Ini</h2>
                    <p class="text-2xl font-bold text-green-600"><?php echo e($visitorsToday); ?></p>
                </div>
                <div class="flex-1 bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-semibold">Pengunjung Minggu Ini</h2>
                    <p class="text-2xl font-bold text-green-600"><?php echo e($visitorsThisWeek); ?></p>
                </div>
                <div class="flex-1 bg-white p-4 rounded shadow">
                    <h2 class="text-lg font-semibold">Pengunjung Bulan Ini</h2>
                    <p class="text-2xl font-bold text-green-600"><?php echo e($visitorsThisMonth); ?></p>
                </div>
            </div>
        </div>

        
        <div x-data="{ open: true }" class="w-full lg:max-w-4xl mb-4">
            <div class="bg-white p-6 rounded shadow">
                <button @click="open = !open" class="text-left w-full text-2xl font-semibold mb-4 flex justify-between items-center">
                    Statistik Mingguan
                    <span x-text="open ? '−' : '+'"></span>
                </button>

                <div x-show="open" x-transition>
                    <?php if(count($weeklyStats) > 0): ?>
                        <canvas id="weeklyStatsChart"></canvas>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                var weeklyStats = <?php echo json_encode($weeklyStats); ?>;
                                const ctx = document.getElementById('weeklyStatsChart').getContext('2d');

                                new Chart(ctx, {
                                    type: 'line',
                                    data: {
                                        labels: weeklyStats.map(stat => {
                                            const date = new Date(stat.date);
                                            return date.toLocaleDateString('id-ID', {
                                                weekday: 'short',
                                                day: 'numeric',
                                                month: 'short'
                                            });
                                        }),
                                        datasets: [{
                                            label: 'Jumlah Pengunjung',
                                            data: weeklyStats.map(stat => Number(stat.total)),
                                            borderColor: 'rgba(75, 192, 192, 1)',
                                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                            borderWidth: 2,
                                            tension: 0.3,
                                            pointRadius: 4,
                                            pointHoverRadius: 6
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: true,
                                                position: 'top'
                                            },
                                            tooltip: {
                                                mode: 'index',
                                                intersect: false
                                            }
                                        },
                                        scales: {
                                            y: {
                                                beginAtZero: true,
                                                ticks: {
                                                    stepSize: 10,
                                                    callback: function(value) {
                                                        return Number.isInteger(value) ? value : null;
                                                    }
                                                },
                                                title: {
                                                    display: true,
                                                    text: 'Jumlah Pengunjung'
                                                }
                                            },
                                            x: {
                                                title: {
                                                    display: true,
                                                    text: 'Tanggal'
                                                }
                                            }
                                        }
                                    }
                                });
                            });
                        </script>
                    <?php else: ?>
                        <p class="text-gray-500">Belum ada data pengunjung minggu ini.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div x-data="{ open: true }" class="w-full lg:max-w-4xl mb-10">
            <div class="bg-white p-6 rounded shadow">
                <button @click="open = !open" class="text-left w-full text-2xl font-semibold mb-4 flex justify-between items-center">
                    Statistik Bulanan
                    <span x-text="open ? '−' : '+'"></span>
                </button>

                <div x-show="open" x-transition>
                    <?php if(count($monthlyStatsByWeek) > 0): ?>
                        <canvas id="monthlyStatsChart" width="400" height="200"></canvas>
                        <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                var monthlyStats = <?php echo json_encode($monthlyStatsByWeek); ?>;
                                const ctx = document.getElementById('monthlyStatsChart').getContext('2d');

                                new Chart(ctx, {
                                    type: 'line',
                                    data: {
                                        labels: monthlyStats.map(stat => stat.week),
                                        datasets: [{
                                            label: 'Jumlah Pengunjung',
                                            data: monthlyStats.map(stat => Number(stat.total)),
                                            borderColor: 'rgba(75, 192, 192, 1)',
                                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                                            borderWidth: 2,
                                            tension: 0.3,
                                            pointRadius: 4,
                                            pointHoverRadius: 6
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: true,
                                                position: 'top'
                                            },
                                            tooltip: {
                                                mode: 'index',
                                                intersect: false
                                            }
                                        },
                                        scales: {
                                            y: {
                                                beginAtZero: true,
                                                ticks: {
                                                    stepSize: 10,
                                                    callback: function(value) {
                                                        return Number.isInteger(value) ? value : null;
                                                    }
                                                },
                                                title: {
                                                    display: true,
                                                    text: 'Jumlah Pengunjung'
                                                }
                                            },
                                            x: {
                                                title: {
                                                    display: true,
                                                    text: 'Tanggal'
                                                }
                                            }
                                        }
                                    }
                                });
                            });
                        </script>
                    <?php else: ?>
                        <p class="text-gray-500">Belum ada data pengunjung Bulan ini.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="mb-4 w-full lg:max-w-4xl">
            <h2 class="text-3xl font-bold mb-0">Kelola Konten Website</h2>
            <p class="text-lg text-gray-600">Akses berbagai fitur untuk mengelola website Anda.</p>
        </div>
        <div class="flex flex-col md:flex-row gap-6 justify-between w-full lg:max-w-4xl">
            
            <a href="<?php echo e(route('admin.service.index')); ?>" class="bg-white rounded-lg shadow-md px-10 lg:px-12 py-8 flex flex-col items-center flex-1 hover:shadow-lg transition-shadow">
                <i class="fas fa-cog text-4xl text-teal-500 mb-4"></i>
                <div class="text-2xl font-semibold mb-1">Layanan</div>
                <span class="text-xl font-bold">
                    <?php echo e($serviceCount ? $serviceCount : 0); ?>

                </span>
            </a>
            
            <a href="<?php echo e(route('admin.portfolio.index')); ?>" class="bg-white rounded-lg shadow-md px-10 lg:px-12 py-8 flex flex-col items-center flex-1 hover:shadow-lg transition-shadow">
                <i class="fas fa-briefcase text-4xl text-teal-500 mb-4"></i>
                <div class="text-2xl font-semibold mb-1">Portofolio</div>
                <div class="text-xl font-bold">
                    <?php echo e($portfolioCount ? $portfolioCount : 0); ?>

                </div>
            </a>
            
            <a href="<?php echo e(route('admin.setting.index')); ?>" class="bg-white rounded-lg shadow-md px-10 lg:px-12 py-8 flex flex-col items-center flex-1 hover:shadow-lg transition-shadow">
                <i class="fas fa-cog text-4xl text-teal-500 mb-4"></i>
                <div class="text-2xl font-semibold mb-1">Pengaturan</div>
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
