<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta description="<?php echo e($contact->site_name ? $contact->site_name : config('app.name', 'Harta Gemilang')); ?>">
    <meta name="keywords" content="<?php echo e($contact->site_keywords ? $contact->site_keywords : 'Harta Gemilang, Construction, Services, Pengadaan, Konstruksi'); ?>">

    <title><?php echo e($contact->site_name ? $contact->site_name : config('app.name', 'Harta Gemilang')); ?></title>

    <?php if(!empty($contact->favicon)): ?>
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset($contact->favicon)); ?>">
    <?php endif; ?>

    <link rel="alternate" hreflang="en" href="<?php echo e(url('/en')); ?>">
    <link rel="alternate" hreflang="id" href="<?php echo e(url('/id')); ?>">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>

<body class="font-sans antialiased">
    <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>

</html>
