<section class="bg-gray-900/50 text-white items-center md:pb-0 min-h-[180px]">
    <!-- Background Image -->
    <div class="absolute inset-0 h-full bg-[url('/images/bg-1.jpg')] bg-cover bg-center z-[-2] max-h-[308px] lg:max-h-[324px]"></div>
    <!-- Overlay Gradient -->
    <div class="absolute inset-0 h-full bg-gradient-to-br from-gray-900/100 to-transparent z-[-1] max-h-[308px] lg:max-h-[324px]"></div>

    <div class="container flex flex-col md:flex-row">
        <div class="lg:w-1/2 mb-6 md:mb-0">
            <div class="flex items-center h-full">
                <div class="flex items-center text-lg md:text-2xl text-gray-300 space-x-2 py-10" aria-label="Breadcrumb">
                    <?php 
                        $locale = app()->getLocale();
                        $second = request()->segment(2);
                        $third = request()->segment(3);
                        $label = Lang::has('menu.' . $second) ? trans('menu.' . $second) : ucfirst($second);
                     ?>

                    <div class="flex items-center text-lg md:text-2xl text-gray-300 space-x-2" aria-label="Breadcrumb">
                        <a href="<?php echo e(url($locale . '/')); ?>" class="hover:text-white" <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 200;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                            <?php echo e(trans('menu.home')); ?>

                        </a>
                        <span <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 300;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>>/</span>

                        <?php if($second && $second !== $locale): ?>
                            <?php if($third): ?>
                                <a href="<?php echo e(url($locale . '/' . $second)); ?>" class="hover:text-white" <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 400;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                                    <?php echo e($label); ?>

                                </a>
                                <span <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 500;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>>/</span>
                                <span class="text-white font-semibold" <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 600;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>">
                                    <?php echo e(isset($current) ? $current : ucfirst(str_replace('-', ' ', $third))); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-white font-semibold" <?php
                $ua = request()->header('User-Agent');
                $delayFinal = (preg_match('/Mobile|Android|iPhone/', $ua)) ? 200 : 400;
                $anchorAttr = '';
                $offsetAttr = '';
                printf('data-aos="%s" data-aos-delay="%d"%s%s', 'fade-left', $delayFinal, $anchorAttr, $offsetAttr);
            ?>>
                                    <?php echo e(isset($current) ? $current : $label); ?>

                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
