<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.pageBanner', ['current' => $service->service_name ? $service->service_name->translated_text : 'Test Service'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="py-20">
        <div class="container">
            <div class="flex flex-col gap-8">
                <div class="flex flex-col md:flex-row gap-8">
                    <div class="w-full md:w-2/3 bg-white p-8 rounded-lg shadow-lg">
                        <img src="<?php echo e(asset($service->image)); ?>" alt="image.jpg" class="w-full object-cover rounded-lg mb-6">
                        <h2 class="text-4xl font-bold mb-4"><?php echo e($service->service_name ? $service->service_name->translated_text : 'title'); ?></h2>
                        <?php 
                            $content = isset($service->service_content) ? $service->service_content->translated_text : '';
                            $lines = explode("\n", $content);
                         ?>
                        <div class="text-gray-700">
                            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p class="mb-6"><?php echo e(trim($line)); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="w-full md:w-1/3 md:p-8">
                        
                        <h3 class="text-2xl font-semibold mb-4"><?php echo e(__('service.other_services')); ?></h3>
                        <div class="flex flex-col gap-6">
                            <?php $__currentLoopData = $otherServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('service.show', ['lang' => app()->getLocale(), 'slug' => $otherService->slug])); ?>" class="bg-white p-4 lg:p-6 rounded-lg shadow hover:shadow-lg transition-shadow duration-300">
                                    <div class="w-full h-48 overflow-hidden rounded mb-4">
                                        <img src="<?php echo e(asset($otherService->image)); ?>" alt="<?php echo e($otherService->service_name ? $otherService->service_name->translated_text : 'title'); ?>" class="w-full h-48 object-cover hover:scale-105 transition-transform duration-300">
                                    </div>
                                    <h4 class="text-xl font-semibold mb-2"><?php echo e($otherService->service_name ? $otherService->service_name->translated_text : 'title'); ?></h4>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
