<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.pageBanner', ['current' => __('menu.services')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <section class="py-20">
        <div class="container">
            <div class="flex flex-col gap-8">
                <div class="flex flex-col md:flex-row gap-8">
                    <div class="w-full md:w-2/3 bg-white p-8 rounded-lg shadow-lg">
                        <div class="flex flex-col mb-6">
                            <!-- image utama -->
                            <div class="w-full rounded-lg overflow-hidden bg-gray-100 shadow">
                                <img id="mainImage" src="<?php echo e(asset('storage/' . $portfolio->image_1)); ?>" alt="main_image.jpg" class="w-full object-cover rounded-lg transition-opacity duration-500 opacity-100">
                            </div>
                            <!-- image tambahan -->
                            <div class="flex flex-row gap-4 justify-start items-center mt-4 scrollbar-x overflow-x-auto">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <?php  $key = 'image_' . $i;  ?>
                                    <?php if(!empty($portfolio->image_2)): ?>
                                        <div class="flex-shrink-0 w-auto h-24 max-w-[165px] lg:h-28 mb-4 rounded-lg overflow-hidden bg-gray-100 shadow cursor-pointer thumbnail-container">
                                            <?php if(!empty($portfolio->$key)): ?>
                                                <img src="<?php echo e(asset('storage/' . $portfolio->$key)); ?>" alt="image_<?php echo e($i); ?>.jpg" class="thumbnail-img w-full h-full object-cover rounded-lg transition hover:scale-105 duration-300 border-4 border-transparent" onclick="document.getElementById('mainImage').src = this.src">
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                        <h2 class="text-4xl font-bold mb-4"><?php echo e($portfolio->project_name ? $portfolio->project_name->translated_text : 'title'); ?></h2>
                        <p class="text-gray-600 mb-4"><?php echo e($portfolio->project_desc ? $portfolio->project_desc->translated_text : 'description'); ?></p>
                        <div class="text-gray-700">
                            <?php 
                                $content = isset($portfolio->project_content) ? $portfolio->project_content->translated_text : '';
                                $lines = explode("\n", $content);
                             ?>

                            <ul class="list-disc pl-5 space-y-1">
                                <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(trim($line)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="w-full md:w-1/3 p-8">
                        <h3 class="text-2xl font-semibold mb-4"><?php echo e(__('portfolio.other_portfolios')); ?></h3>
                        <div class="flex flex-col gap-6">
                            <?php $__currentLoopData = $otherPortfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherPortfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="group relative overflow-hidden rounded-xl shadow-lg cursor-pointer">
                                    <a href="<?php echo e(route('portfolio.show', ['lang' => app()->getLocale(), 'slug' => $otherPortfolio->slug])); ?>" class="block">
                                        <img src="<?php echo e(asset('storage/' . $otherPortfolio->image_1)); ?>" alt="<?php echo e($otherPortfolio->project_name ? $otherPortfolio->project_name->translated_text : 'Untitled'); ?>" class="w-full object-cover transition-transform duration-500 group-hover:scale-110 group-hover:brightness-75">

                                        <!-- Hover overlay on desktop -->
                                        <div class="absolute inset-0 hidden md:flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40">
                                            <span class="text-white text-xl font-semibold tracking-wide">
                                                <?php echo e($otherPortfolio->project_name ? $otherPortfolio->project_name->translated_text : 'Untitled'); ?>

                                            </span>
                                        </div>

                                        <!-- Project name for mobile view -->
                                        <div class="md:hidden absolute bottom-2 right-3 bg-black/60 px-2 py-1 rounded text-white text-sm font-medium">
                                            <?php echo e($otherPortfolio->project_name ? $otherPortfolio->project_name->translated_text : 'Untitled'); ?>

                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
