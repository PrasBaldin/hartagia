@extends('admin.layouts.app')

@section('breadcrumb')
    <li class="inline-flex items-center">
        <span class="mx-2 text-gray-500">/</span>
        <a href="{{ route('admin.portfolio.index') }}" class="text-gray-500 hover:text-gray-700 transition">Portfolio</a>
        <span class="mx-2 text-gray-500">/</span>
        <span class="text-gray-700">{{ $portfolio->project_name ? $portfolio->project_name->translated_text : '-' }}</span>
    </li>
@endsection

@section('content')
    @include('components.alerts')
    <div class="flex flex-col md:flex-row justify-center items-start gap-6">
        <div class="p-8 bg-white rounded-lg shadow-md w-full md:w-3/4">
            <div class="flex flex-col mb-6">
                <!-- image utama -->
                <div class="w-full rounded-lg overflow-hidden bg-gray-100 shadow">
                    <img id="mainImage" src="{{ asset($portfolio->image_1) }}" alt="main_image.jpg" class="w-full object-cover rounded-lg transition-opacity duration-500 opacity-100">
                </div>
                <!-- image tambahan -->
                <div class="flex flex-row gap-4 justify-start items-center mt-4 scrollbar-x overflow-x-auto">
                    @for ($i = 1; $i <= 5; $i++)
                        @php $key = 'image_' . $i; @endphp
                        @if (!empty($portfolio->image_2))
                            <div class="flex-shrink-0 w-auto h-24 max-w-[165px] lg:h-28 mb-4 rounded-lg overflow-hidden bg-gray-100 shadow cursor-pointer thumbnail-container">
                                @if (!empty($portfolio->$key))
                                    <img src="{{ asset($portfolio->$key) }}" alt="image_{{ $i }}.jpg" class="thumbnail-img w-full h-full object-cover rounded-lg transition hover:scale-105 duration-300 border-4 border-transparent" onclick="document.getElementById('mainImage').src = this.src">
                                @endif
                            </div>
                        @endif
                    @endfor
                </div>
            </div>
            <h2 class="text-4xl font-bold mb-4">{{ $portfolio->project_name ? $portfolio->project_name->translated_text : 'title' }}</h2>
            <p class="text-gray-600 mb-4">{{ $portfolio->project_desc ? $portfolio->project_desc->translated_text : 'description' }}</p>
        </div>
        <div class="p-8 bg-white rounded-lg shadow-md w-full md:w-1/4">
            <div class="flex flex-col gap-4">
                <a href="{{ route('admin.portfolio.edit', $portfolio->id) }}" class="bg-blue-500 hover:bg-blue-700 text-white text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300">
                    <i class="fas fa-edit"></i>
                    <span>Edit</span>
                </a>
                <form id="delete-form-{{ $portfolio->id }}" action="{{ route('admin.portfolio.destroy', $portfolio->id) }}" method="POST">
                    {{ csrf_field() }}
                    {{ method_field('DELETE') }}
                    <button type="button" class="w-full bg-red-500 hover:bg-red-700 text-white text-sm font-semibold py-2 px-4 rounded-lg flex items-center gap-2 transition duration-300" onclick="confirmDelete({{ $portfolio->id }})">
                        <i class="fas fa-trash"></i>
                        <span>Hapus</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
@endsection

{{-- linguist trigger --}}
