<?php

return [
    'title' => 'Join Us',
    'subtitle' => 'Consult your project needs with us and find the right solution for the best achievement.',
];
