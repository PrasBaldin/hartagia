<?php

return [
    'home' => 'Home',
    'about' => 'About',
    'services' => 'Services',
    'portfolio' => 'Portfolio',
    'eCatalog' => 'e-Catalog',
    'contact' => 'Contact',
    'language' => 'Change Language',
];
