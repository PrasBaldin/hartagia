<?php

return [
    'about_title' => 'About Us',
    'about_desc' => 'PT. HARTA GEMILANG ASELINDO is a leading procurement and construction specialist with extensive experience in the industry.',
    'quick_links' => 'Quick Links',
    'contact_title' => 'Contact Info',
    'email_subtitle' => 'Email',
    'phone_subtitle' => 'Phone',
    'address_subtitle' => 'Address',
    'rights' => 'All rights reserved.',
];
