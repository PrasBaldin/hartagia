<?php

return [
    'title' => 'Contact Us',
    'subtitle' => 'Contact Us for More Information',
    'form' => [
        'title' => 'Send a Message',
        'name' => 'Name',
        'email' => 'Email',
        'phone' => 'Phone',
        'message' => 'Message',
        'send' => 'Send Message',
    ],
    'button' => 'Contact Us',
    'view_eCatalog' => 'View e-Catalog',
];
