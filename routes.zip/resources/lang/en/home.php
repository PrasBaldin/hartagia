<?php

return [
    'headline' => 'Procurement & Construction Specialist',
    'subheadline' => 'Providing high-quality procurement and construction solutions for the government and private sectors.',
];
