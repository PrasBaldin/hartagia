<?php

return [
    'title' => 'Kontak Kami',
    'subtitle' => 'Hubungi Kami untuk Informasi Lebih Lanjut',
    'form' => [
        'title' => 'Kirim Pesan',
        'name' => 'Nama',
        'email' => 'Email',
        'phone' => 'Telepon',
        'message' => 'Pesan',
        'send' => 'Kirim Pesan',
    ],
    'button' => 'Hubungi Kami',
    'view_eCatalog' => 'Lihat e-Katalog',
];
