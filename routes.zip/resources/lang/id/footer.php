<?php

return [
    'about_title' => 'Tentang Kami',
    'about_desc' => 'PT. HARTA GEMILANG ASELINDO adalah perusahaan jasa konstruksi dan pengadaan barang yang menyediakan layanan komprehensif dan inovatif',
    'quick_links' => 'Tautan Cepat',
    'contact_title' => 'Info Kontak',
    'email_subtitle' => 'Email',
    'phone_subtitle' => 'Telepon',
    'address_subtitle' => 'Alamat',
    'rights' => 'Semua hak dilindungi.',
];
