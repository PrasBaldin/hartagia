<?php

return [
    'headline' => 'Spesialis Pengadaan & Konstruksi',
    'subheadline' => 'Menyediakan solusi pengadaan dan konstruksi berkualitas tinggi untuk sektor pemerintahan dan swasta.',
];
