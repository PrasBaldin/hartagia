<?php

return [
    'title' => 'Bergabunglah Bersama Kami',
    'subtitle' => 'Konsultasikan kebutuhan proyek Anda dengan kami dan temukan solusi yang tepat untuk pencapaian terbaik.',
];
