<?php

return [
    'title' => 'Galeri',
    'subtitle' => 'Jelajahi Karya dan Pencapaian Kami',
    'description' => 'Temukan kualitas dan profesionalisme yang tercermin dalam proyek kami. Kami berkomitmen untuk keunggulan dan inovasi dalam setiap aspek pekerjaan kami.',
    'view_all' => 'Lihat Semua Galeri',
    'captions' => [
        '1' => 'caption',
        '2' => 'caption',
        '3' => 'caption',
        '4' => 'caption',
        '5' => 'caption',
        '6' => 'caption',
    ],
];
