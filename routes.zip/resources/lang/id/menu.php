<?php

return [
    'home' => 'Beranda',
    'about' => 'Tentang',
    'services' => 'Layanan',
    'eCatalog' => 'e-Katalog',
    'portfolio' => 'Portofolio',
    'contact' => 'Kontak',
    'language' => 'Ganti Bahasa',
];
